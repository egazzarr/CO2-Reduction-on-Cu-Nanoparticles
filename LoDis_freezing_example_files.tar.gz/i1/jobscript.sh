#!/bin/bash
#
#SBATCH --job-name=Cu561f_s
#####SBATCH --output=output.out
#SBATCH --mail-type=END
#SBATCH --partition=henryb
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G

srun hostname
srun sleep 60

/home/k1630891/sharedscratch/LoDiS/LoDiS_GIT/base/LODIS_all < input.in > output.out

#/home/k1630891/sharedscratch/LoDiS/LoDis_GIT/base/LODIS_all < input.in > output1000000.out
